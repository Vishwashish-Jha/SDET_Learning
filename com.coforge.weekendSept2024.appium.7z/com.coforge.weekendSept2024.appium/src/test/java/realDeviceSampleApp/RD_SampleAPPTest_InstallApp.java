package realDeviceSampleApp;

import java.util.List;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;

public class RD_SampleAPPTest_InstallApp extends BaseTest {
	

	@Test
	public void verifyListTest() throws Exception {
		
		System.out.println("perform action on application");
//		driver.findElement(By.id("android:id/text1")).click();    //multiple match
		
		
		List<MobileElement> all_ele = driver.findElements(By.id("android:id/text1"));
		
		System.out.println("Element Count: " + all_ele.size());
		
		
		for (int i = 0; i < all_ele.size(); i++) {
			
			
			
			String ele_text =all_ele.get(i).getText();
			System.out.println("element text are: " + i +  " : " + ele_text);
			
			
			if(ele_text.equalsIgnoreCase("OS")) {
				
				System.out.println("-------click on element");
				Thread.sleep(3000);
				all_ele.get(i).click();
				break;
			}
			
			
		}
		
		
		

		
	}
	
	
	

}

package realDeviceSampleApp;

import org.testng.annotations.Test;

public class RD_SampleAPPTest_AccID extends BaseTest {
	

	@Test
	public void verifyListTest() throws Exception {
		
		System.out.println("perform action on application");

		
//		//ios
//		AccessibilityId ------- iOS
//		
//		//android
//		content-desc ------- iOS
		
		driver.findElementByAccessibilityId("OS").click();
		

		
	}
	
	
	

}

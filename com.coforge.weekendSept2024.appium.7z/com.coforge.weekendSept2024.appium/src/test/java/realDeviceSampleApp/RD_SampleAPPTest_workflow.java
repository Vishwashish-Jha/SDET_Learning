package realDeviceSampleApp;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class RD_SampleAPPTest_workflow extends BaseTest {
	

	@Test
	public void verifyListTest() throws Exception {
		
		System.out.println("perform action on application");

		
//		//ios
//		AccessibilityId ------- iOS
//		
//		//android
//		content-desc ------- iOS
		
		//click on OS
		driver.findElementByAccessibilityId("OS").click();
		
		//click on SMS Messaging
		driver.findElementByAccessibilityId("SMS Messaging").click();
		
		
		
		driver.findElement(By.id("sms_recipient")).sendKeys("Sushil Gupta");
		driver.findElement(By.id("sms_content")).sendKeys("Hi, thanks !!");
		
		//click on Send
		driver.findElementByAccessibilityId("Send").click();
		
		
		
	}
	
	
	

}

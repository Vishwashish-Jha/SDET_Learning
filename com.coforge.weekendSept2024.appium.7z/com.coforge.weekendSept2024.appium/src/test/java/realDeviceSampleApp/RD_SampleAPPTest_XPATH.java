package realDeviceSampleApp;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class RD_SampleAPPTest_XPATH extends BaseTest {
	

	@Test
	public void verifyListTest() throws Exception {
		
		System.out.println("perform action on application");

		
		//click on OS
		driver.findElement(By.xpath("//*[@content-desc='OS']")).click();
		
		
		//click on SMS Messaging
		driver.findElement(By.xpath("//*[@content-desc='SMS Messaging']")).click();
		
		
	}
	
	
	

}
